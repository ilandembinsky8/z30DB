package lib;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;

public class UpdateCommand extends SQLCommand {

	public UpdateCommand() {
		super("update");
		// TODO Auto-generated constructor stub
	}
	
	public Boolean signUp(java.sql.Connection con,String email, String password, String firstName, String LastName, 
			genderType gender, Date date, String userType) throws SQLException{
		if ((email == null)||(email.length() == 0)||(password == null)||(password.length() == 0)||
				(firstName == null)||(firstName.length() == 0)||(LastName == null)||(LastName.length() == 0)
				)
			return false;
		
		SelectCommand helper = new SelectCommand();
		ArrayList<String> answer = helper.runLoginSearch(con, email, password);
		if (answer.get(1) == "success")
			return false;
		int curatorRequest = 1;
		if (userType.equals("Curator") )
			curatorRequest = 2;
		User newUser = new User(1,email,password,firstName,LastName,gender,date,true,userType,
				curatorRequest);
		char wantPlay = 'Y';
		
		Statement stmt = con.createStatement();
		String insert = "INSERT INTO user (email, password, firstName, lastName, gender, birthday, wantToPlay,"
				+ "userTypeID,curatorRequest) VALUES('"+email+"', '"+password+"', '"+firstName+"', '"+LastName+"', '"+gender+"', '"+
				date+"', '"+wantPlay+"', 1,"+curatorRequest+")";
//		String insert2 = "INSERT INTO user (email, password, firstName, lastName, gender, birthday, wantToPlay,"
//				+ "userTypeID,curatorRequest) VALUES('rosenbaum@eyal', '123456', 'eyal', 'rosenbaum', 'm', '1983-06-11', true, 1,1)";
		stmt.executeUpdate(insert);
		
		PreparedStatement passwordStatement =con.prepareStatement("SELECT * from user WHERE  email = ? AND password = ?");
		passwordStatement.setString(1, email);
		passwordStatement.setString(2, password);
		ResultSet rs = passwordStatement.executeQuery();
		if (!rs.next()){
			return false;
		}
		else return true;

	}

}
