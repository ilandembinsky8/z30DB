package lib;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.omg.CORBA.Request;

public class SelectCommand extends SQLCommand {

	private ArrayList<String> column;
	private String tableName;
	private ArrayList<String> joins;
	private ArrayList<String> where;
	private String query = null;

	public SelectCommand(){
		super("select");
		this.column = null;
		this.tableName = null;
		this.joins = null;
		this.where = null;
	}
	


	public SelectCommand(ArrayList<String> column, String tableName, ArrayList<String> joins,
			ArrayList<String> where) {
		super("select");
		this.column = column;
		this.tableName = tableName;
		this.joins = joins;
		this.where = where;
	}
	
	public User returnUserByUsername (java.sql.Connection con, String username) throws SQLException{
		PreparedStatement passwordStatement = con.prepareStatement("select * from libArabDB.user inner join libArabDB.usertype"
				+ " on user.userTypeID=usertype.userTypeID where email = ? AND password = ?");
		passwordStatement.setString(1, username);
		User result;
		ResultSet rs = passwordStatement.executeQuery();
		//in case no match was found
		if (!rs.next())
			return null;
		else{
				result = new User(rs.getInt("userID"), rs.getString("email"), rs.getString("password"),
				rs.getString("firstName"), rs.getString("lastName"), genderType.valueOf(rs.getString("gender")),
				rs.getDate("birthday"), rs.getBoolean("wantToPlay"),rs.getString("type"),
				rs.getInt("curatorRequest"));
			
		}
		return result;	
	}
	
	public ArrayList<User> returnAllUsers(java.sql.Connection con , int n ) throws SQLException{

		ArrayList<User> all = new ArrayList<User>();
		java.sql.Statement allStatement =con.createStatement();
		this.query = "select * from libArabDB.user inner join libArabDB.usertype on user.userTypeID=libArabDB.usertype.userTypeID "
				+ "where libArabDB.user.birthday not in ('0000-00-00')";
		
		ResultSet rs = allStatement.executeQuery(this.query);
		if(n==0)
		{
			while(rs.next())
			{
				User user = new User(rs.getInt("userID"), rs.getString("email"), rs.getString("password"),
						rs.getString("firstName"), rs.getString("lastName"), genderType.valueOf(rs.getString("gender")),
						rs.getDate("birthday"), rs.getBoolean("wantToPlay"),rs.getString("type"),
						rs.getInt("curatorRequest"));
				all.add(user);
			}
		}
		
		else 
		{
		while (rs.next() & n!=0){
			User user = new User(rs.getInt("userID"), rs.getString("email"), rs.getString("password"),
					rs.getString("firstName"), rs.getString("lastName"), genderType.valueOf(rs.getString("gender")),
					rs.getDate("birthday"), rs.getBoolean("wantToPlay"),rs.getString("type"),
					rs.getInt("curatorRequest"));
			all.add(user);
			n--; 
			
		}
		}
		return all;
	}
	
	public ArrayList<User> returnAllCuratorsPending (java.sql.Connection con) throws SQLException{
		ArrayList<User> curatorPending = new ArrayList<User>();
		java.sql.Statement allStatement =con.createStatement();
		
		String s = "select * from libArabDB.user inner join libArabDB.usertype on user.userTypeID="
				+ "libArabDB.user.userTypeID where libArabDB.user.birthday  not in ('0000-00-00') and"
				+ " libArabDB.user.userTypeID = 1 and libArabDB.user.curatorRequest = 2";
		
		ResultSet rs = allStatement.executeQuery(s);
		
		while (rs.next()){
			User user = new User(rs.getInt("userID"), rs.getString("email"), rs.getString("password"),
					rs.getString("firstName"), rs.getString("lastName"), genderType.valueOf(rs.getString("gender")),
					rs.getDate("birthday"), true, rs.getString("type"),
					rs.getInt("curatorRequest"));
			curatorPending.add(user);
		}
		return curatorPending;
	}
	
	public ArrayList<User> returnAllCurators(java.sql.Connection con) throws SQLException{

		ArrayList<User> curator = new ArrayList<User>();
		java.sql.Statement allStatement =con.createStatement();
		//String s ="SELECT * from user WHERE userTypeID = 2";
		String s = "select * from libArabDB.user inner join libArabDB.usertype on user.userTypeID="
				+ "libArabDB.user.userTypeID where libArabDB.user.birthday  not in ('0000-00-00') and"
				+ " libArabDB.user.userTypeID = 2";
		ResultSet rs = allStatement.executeQuery(s);
		
		while (rs.next()){
			User user = new User(rs.getInt("userID"), rs.getString("email"), rs.getString("password"),
					rs.getString("firstName"), rs.getString("lastName"), genderType.valueOf(rs.getString("gender")),
					rs.getDate("birthday"), rs.getBoolean("wantToPlay"),rs.getString("type"),
					rs.getInt("curatorRequest"));
		//	System.out.println(user.getEmail());
		//	if(user.getUserTypeID() == 2){
			curator.add(user);
			}
		return curator;
	}
	
	public ArrayList<String> runLoginSearch(java.sql.Connection con, String username, String password) throws SQLException{
//		PreparedStatement usernameStatement =con.prepareStatement("SELECT * from user WHERE  email = ?");
//		usernameStatement.setString(1, username);
		//PreparedStatement passwordStatement =con.prepareStatement("SELECT * from user WHERE  email = ? AND password = ?");
		PreparedStatement passwordStatement = con.prepareStatement("select * from libArabDB.user inner join libArabDB.usertype"
				+ " on user.userTypeID=usertype.userTypeID where email = ? AND password = ?");
		passwordStatement.setString(1, username);
		passwordStatement.setString(2, password);
		ArrayList<String> replyList = new ArrayList<String>();
		String replyClient = "fail";
		String userNameReply ="";
//		ResultSet rs = usernameStatement.executeQuery();
//		if (!rs.next())
//			return 1;
//		else {
//			rs = passwordStatement.executeQuery();
//			if (!rs.next())
//				return 2;
//			else 
//				return 3;
//		}
		ResultSet rs = passwordStatement.executeQuery();
		//in case no match was found
		if (!rs.next()){
			replyList.add("Incorrect Email or Password");
			replyList.add(replyClient);
			replyList.add("");
			return replyList;
		}
		else{
			User userA = new User(rs.getInt("userID"), rs.getString("email"), rs.getString("password"),
					rs.getString("firstName"), rs.getString("lastName"), genderType.valueOf(rs.getString("gender")),
					rs.getDate("birthday"), rs.getBoolean("wantToPlay"),rs.getString("type"),
					rs.getInt("curatorRequest"));
			userNameReply = userA.getFirstName()+" "+userA.getLastName();
			replyClient = "success";
			if (userA.getUserType().equals("Regular")) {	
				if (userA.getCuratorRequest() == 2){
					replyList.add("Curator not approved User");
					replyList.add(replyClient);
					replyList.add(userNameReply);
					return replyList;
				}
				else {
					replyList.add("Regular user");
					replyList.add(replyClient);
					replyList.add(userNameReply);
					return replyList;
				}
			}
			else if (userA.getUserType().equals("Curator")){
				replyList.add("Curator approved User");
				replyList.add(replyClient);
				replyList.add(userNameReply);
				return replyList;
			}
			else if (userA.getUserType().equals("Admin")){
				replyList.add("Admin");
				replyList.add(replyClient);
				replyList.add(userNameReply);
				return replyList;
			}
		}
		return null;
	
	}
//	public String generateQuery(ArrayList<String> requestedColumn, String requestedTable, ArrayList<String> requestedJoins,
//	ArrayList<String> requestedWhere){
//String result = "SELECT ";
//if (requestedColumn.size() == 1)
//	result += requestedColumn.get(0);
//else for (int i=0; i<requestedColumn.size(); i++){
//		result += requestedColumn.get(i);
//		if (i != (requestedColumn.size()-1))
//			result += ", ";
//}
//
//result +=" FROM "+requestedTable;
//if (requestedJoins != null){
//
//}
//else{
//	if (requestedWhere != null){
//		result+=" WHERE";
//		if (requestedColumn.size() == 1)
//			result += requestedColumn.get(0);
//		else for (int i=0; i<requestedColumn.size(); i++){
//				result += requestedColumn.get(i);
//				if (i != (requestedColumn.size()-1))
//					result += "AND ";
//		}
//	}	
//}
//return result;
//}

}
