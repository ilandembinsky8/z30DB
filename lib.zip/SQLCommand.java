package lib;

public abstract class SQLCommand {
	private String type;


	public SQLCommand(String type) {
		super();
		this.type = type;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
}
