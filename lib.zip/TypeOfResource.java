package lib;

public enum TypeOfResource {
	BOOK , MAP , HANDWRITING , MAGAZINE , SHEET
}
