package lib;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

public class ReturnAllUsers extends SQLCommand  {
	
	private ArrayList<User> all;
	public ReturnAllUsers() {
		super("search");
		all = new ArrayList<User>();
	}

	public ArrayList<User> returnAll(java.sql.Connection con) throws SQLException{

		java.sql.Statement allStatement =con.createStatement();
		String s ="SELECT * from user";
		ResultSet rs = allStatement.executeQuery(s);
		
		while (rs.next()){
			User user = new User(rs.getInt("userID"), rs.getString("email"), rs.getString("password"),
					rs.getString("firstName"), rs.getString("lastName"), genderType.valueOf(rs.getString("gender")),
					rs.getDate("birthday"), rs.getBoolean("wantToPlay"),rs.getInt("userTypeID"),
					rs.getInt("curatorRequest"));
			//System.out.println(user.getEmail());
			all.add(user);
			
		}
		return all;
	}

}
