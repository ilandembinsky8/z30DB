package lib;

public enum genderType {
	 m,f
}
